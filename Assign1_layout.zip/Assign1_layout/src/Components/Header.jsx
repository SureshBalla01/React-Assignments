import React from "react";
function Header() {
    return (
    <div style={{ border: "4px solid grey", color: "lightgreen", margin:"5px" }}>
        <h2>Header</h2>
    </div>
    );
}

export default Header;