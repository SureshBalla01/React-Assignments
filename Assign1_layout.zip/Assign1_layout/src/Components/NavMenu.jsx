import React from "react";

function NavMenu() {
    return (
        <div
      style={{ border: "4px solid grey", margin: "5px", color: "lightgreen" }}
    >
      <h2>Navigation Menu</h2>
    </div>
    );
}

export default  NavMenu;