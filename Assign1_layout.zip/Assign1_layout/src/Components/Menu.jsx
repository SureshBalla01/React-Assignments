import React from "react";

export default function Menu() {
  return (
    <div
      style={{ border: "4px solid grey", margin: "5px", color: "lightgreen" }}
    >
      <h1>Navigation Menu</h1>
    </div>
  );
}
