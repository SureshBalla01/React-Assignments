import React from "react";

function Footer() {
    return (
        <div style={{ border: "4px solid grey", margin: "5px", color: "lightgreen" }}>
            <h2>Footer</h2>
        </div>
    );
}

export default Footer;