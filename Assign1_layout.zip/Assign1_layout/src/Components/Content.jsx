import React from "react";

function Content () {
    return (
        <div
        style={{
          border: "4px solid grey",
          width: "20%",
          height: "300px",
          margin: "0px 5px",
          color: "lightgreen",
          display: "flex",
          justifyContent: "center",
          alignItems: "center"
        }}
      >
        <h2>Content</h2>
      </div>
  
    );
}

export default Content;