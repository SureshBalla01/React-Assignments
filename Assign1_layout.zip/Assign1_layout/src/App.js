import './App.css';
import Header from './Components/Header';
import NavMenu from './Components/NavMenu';
import Footer from './Components/Footer';
import Content from './Components/Content';
import MainContent from './Components/MainContent';

function App() {
  return (
    <div className='App'>
      <Header />
      <NavMenu />
      <div style={{display: "flex", justifyContent:"space-inbetween"}}>
        <Content />
        <MainContent />
        <Content />
      </div>
      <Footer />
    </div>
  );
}

export default App;
