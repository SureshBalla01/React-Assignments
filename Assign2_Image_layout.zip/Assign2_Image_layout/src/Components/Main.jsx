import React from "react";
import "./Main.css";

export default function Main() {
  let imgArray = [
    {
      img: "https://cdn.pixabay.com/photo/2023/01/10/09/51/sand-dunes-7709400_960_720.jpg"
    },
    {
      img: "https://cdn.pixabay.com/photo/2023/01/05/22/10/mountains-7699910_960_720.jpg"
    },
    {
      img: "https://cdn.pixabay.com/photo/2022/12/07/23/28/way-7642285_960_720.jpg"
    },
    {
      img: "https://cdn.pixabay.com/photo/2023/01/01/16/35/street-7690347_960_720.jpg"
    }
  ];
  let paragraph = `Lorem ipsum dolor sit amet consectetur adipisicing elit. Ducimus
  voluptates labore repudiandae a eum quia itaque consectetur
  eaque iure est! Ea, adipisci. Lorem ipsum dolor sit amet
  consectetur, adipisicing elit. Aliquam, mollitia recusandae.`;
  return (
    <div>
      <main>
        <div className="section-1">
          <img
            src="https://cdn.pixabay.com/photo/2022/12/23/16/03/sunrise-7674594_960_720.jpg"
            alt="img"
          />
        </div>
        <div className="section-2">
          {imgArray.map((el) => (
            <div className="card">
              <img src={el.img} alt="" />
              <p>{paragraph}</p>
              <a href="#">more..</a>
            </div>
          ))}
        </div>
        <div className="section-3">
          <div class="left-col">
            {imgArray.map((el) => (
              <img src={el.img} alt="" />
            ))}
          </div>
          <div className="right-col">
            <h3>Welcome to the side</h3>
            <p>
              <span></span>
              {paragraph}
              {paragraph}
            </p>
            <a href="#">more..</a>
          </div>
        </div>
      </main>
    </div>
  );
}
